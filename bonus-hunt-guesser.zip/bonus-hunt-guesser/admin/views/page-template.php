<?php
/**
 * Pre-made WordPress page template for demo.
 *
 * Usage: [bhg_bonus_hunt] [bhg_leaderboard] [bhg_tournament_leaderboard].
 *
 * @package Bonus_Hunt_Guesser
 */
