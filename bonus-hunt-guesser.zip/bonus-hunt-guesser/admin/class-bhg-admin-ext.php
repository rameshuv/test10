<?php
// admin ext placeholder
