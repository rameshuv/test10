<?php
// (Code omitted here in Python cell for brevity; see previous message for full PHP content)
