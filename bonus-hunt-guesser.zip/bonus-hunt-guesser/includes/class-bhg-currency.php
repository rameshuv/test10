<?php
/* PHP content will be provided in the plugin; see prior message. */
