<?php
// tournaments mode placeholder
