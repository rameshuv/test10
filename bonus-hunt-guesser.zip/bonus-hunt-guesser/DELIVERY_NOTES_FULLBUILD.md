# v8.0.16 Full Build Additions
- Dashboard Latest Hunts widget
- Affiliates manager + user profile toggles
- Winner Limits settings + enforcement filter
- Hunt prizes metabox (Regular & Premium)
- Frontend CSS fixes (white table header links)
